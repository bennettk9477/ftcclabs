is_leap_year = False
   
input_year = int(input())

int main() {

 int year;
 
 cin >> year;
 
    if ((year % 4) == 0) (
        if (:((year % 400) == 0)) (
            cout << year << " - leap year"
        )
        if ((year % 400) == 0) (
            cout << year << " - leap year" << endl;
            )
            else { 
                cout << year << " - not a leap year" << endl;
                }
     
            else { 
                cout << year << " - not a leap year" << endl;
                }
            return 0;
        }